Dummy file for Unix lab.
Path: projects/alpha/src/Main.scala
