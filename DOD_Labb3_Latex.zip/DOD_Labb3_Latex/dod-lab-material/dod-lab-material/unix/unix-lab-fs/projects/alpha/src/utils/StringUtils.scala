Dummy file for Unix lab.
Path: projects/alpha/src/utils/StringUtils.scala
