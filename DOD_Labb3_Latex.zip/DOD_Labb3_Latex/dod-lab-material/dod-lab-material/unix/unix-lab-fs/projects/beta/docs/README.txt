Dummy file for Unix lab.
Path: projects/beta/docs/README.txt
