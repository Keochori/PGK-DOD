Dummy file for Unix lab.
Path: projects/beta/src/Main.scala
