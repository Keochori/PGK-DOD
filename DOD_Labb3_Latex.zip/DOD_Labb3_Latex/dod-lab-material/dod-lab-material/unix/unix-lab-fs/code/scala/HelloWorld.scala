Dummy file for Unix lab.
Path: code/scala/HelloWorld.scala
