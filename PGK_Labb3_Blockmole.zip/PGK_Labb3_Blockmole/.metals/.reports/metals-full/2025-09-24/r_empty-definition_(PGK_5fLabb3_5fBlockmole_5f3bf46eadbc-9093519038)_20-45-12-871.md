error id: file:///C:/Users/Mateusz/Desktop/LTH_PGK_DOD/PGK_Labb3_Blockmole/blockmole.scala:scala/Predef.println(+1).
file:///C:/Users/Mateusz/Desktop/LTH_PGK_DOD/PGK_Labb3_Blockmole/blockmole.scala
empty definition using pc, found symbol in pc: 
empty definition using semanticdb
empty definition using fallback
non-local guesses:
	 -println.
	 -println#
	 -println().
	 -scala/Predef.println.
	 -scala/Predef.println#
	 -scala/Predef.println().
offset: 610
uri: file:///C:/Users/Mateusz/Desktop/LTH_PGK_DOD/PGK_Labb3_Blockmole/blockmole.scala
text:
```scala
//> using dep se.lth.cs::introprog:1.4.0
import java.awt.{Color => JColor}

object Color:
    val black = new JColor( 0, 0, 0)
    val mole = new JColor( 51, 51, 0)
    val soil = new JColor(153, 102, 51)
    val tunnel = new JColor(204, 153, 102)
    val grass = new JColor( 25, 130, 35)

object BlockWindow:
    import introprog.PixelWindow
    val windowSize = (500, 300)
    val blockSize = 10
    val window = new PixelWindow(windowSize._1, windowSize._2, "Blockmole")

object Mole:-
    def dig(): Unit = println("Här ska det grävas!")

object Main:
    def drawWorld(): Unit = printl@@n("Ska rita ut underjorden!")


@main def run(): Unit =
    Main.drawWorld()
```


#### Short summary: 

empty definition using pc, found symbol in pc: 