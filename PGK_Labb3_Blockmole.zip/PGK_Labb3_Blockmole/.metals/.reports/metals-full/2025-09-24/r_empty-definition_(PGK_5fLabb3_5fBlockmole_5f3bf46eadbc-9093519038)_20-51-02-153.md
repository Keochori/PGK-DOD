error id: file:///C:/Users/Mateusz/Desktop/LTH_PGK_DOD/PGK_Labb3_Blockmole/blockmole.scala:scala/Int#
file:///C:/Users/Mateusz/Desktop/LTH_PGK_DOD/PGK_Labb3_Blockmole/blockmole.scala
empty definition using pc, found symbol in pc: scala/Int#
empty definition using semanticdb
empty definition using fallback
non-local guesses:
	 -Int#
	 -scala/Predef.Int#
offset: 510
uri: file:///C:/Users/Mateusz/Desktop/LTH_PGK_DOD/PGK_Labb3_Blockmole/blockmole.scala
text:
```scala
//> using dep se.lth.cs::introprog:1.4.0
import java.awt.{Color => JColor}

object Color:
    val black = new JColor( 0, 0, 0)
    val mole = new JColor( 51, 51, 0)
    val soil = new JColor(153, 102, 51)
    val tunnel = new JColor(204, 153, 102)
    val grass = new JColor( 25, 130, 35)

object BlockWindow:
    import introprog.PixelWindow
    val windowSize = (500, 300)
    val blockSize = 10
    val window = new PixelWindow(windowSize._1, windowSize._2, "Blockmole")

    type Pos = (Int@@, Int)
    def block(pos: Pos)(color: JColor = JColor.gray): Unit =
        val x = pos._1 * blockSize
        val y = pos._2 * blockSize
        window.fill(x,y,blockSize,blockSize, color)


object Mole:
    def dig(): Unit = println("Här ska det grävas!")

object Main:
    def drawWorld(): Unit = println("Ska rita ut underjorden!")

@main def run(): Unit =
    Main.drawWorld()
    BlockWindow.block((10,10))()

```


#### Short summary: 

empty definition using pc, found symbol in pc: scala/Int#