error id: file:///C:/Users/Mateusz/Desktop/LTH_PGK_DOD/PGK_Labb3_Blockmole/blockmole.scala:introprog/PixelWindow#drawText().
file:///C:/Users/Mateusz/Desktop/LTH_PGK_DOD/PGK_Labb3_Blockmole/blockmole.scala
empty definition using pc, found symbol in pc: 
found definition using semanticdb; symbol introprog/PixelWindow#drawText().
empty definition using fallback
non-local guesses:

offset: 398
uri: file:///C:/Users/Mateusz/Desktop/LTH_PGK_DOD/PGK_Labb3_Blockmole/blockmole.scala
text:
```scala
//> using dep se.lth.cs::introprog:1.4.0
import java.awt.{Color => JColor}

object Color:
    val black = new JColor( 0, 0, 0)
    val mole = new JColor( 51, 51, 0)
    val soil = new JColor(153, 102, 51)
    val tunnel = new JColor(204, 153, 102)
    val grass = new JColor( 25, 130, 35)

object BlockWindow:
    

@main def run(): Unit =
    val w = introprog.PixelWindow()
    w.d@@rawText("Hello introprog.PixelWindow!", x = 100, y = 100)
```


#### Short summary: 

empty definition using pc, found symbol in pc: 