//> using dep se.lth.cs::introprog:1.4.0
import java.awt.{Color => JColor}
import scala.compiletime.ops.double
import scala.compiletime.ops.boolean

object Color:
    val black = new JColor( 0, 0, 0)
    val mole = new JColor( 51, 51, 0)
    val soil = new JColor(153, 102, 51)
    val tunnel = new JColor(204, 153, 102)
    val grass = new JColor( 25, 130, 35)

object BlockWindow:
    import introprog.PixelWindow
    val windowSize = (300, 500)
    val blockSize = 10
    val window = new PixelWindow(windowSize._1, windowSize._2, "Blockmole")

    type Pos = (Int, Int)
    def block(pos: Pos)(color: JColor = JColor.gray): Unit =
        val x = pos._1 * blockSize
        val y = pos._2 * blockSize
        window.fill(x,y,blockSize,blockSize, color)

    def rectangle(leftTop: Pos)(size: (Int, Int))(color: JColor = JColor.gray): Unit =
        for y <- 0 until size._2 do
            for x <- 0 until size._1 do
                block(leftTop._1 + x, leftTop._2 + y)(color)

    val maxWaitMillis = 10
    def waitForKey(): String =
        window.awaitEvent(maxWaitMillis)
        while window.lastEventType != PixelWindow.Event.KeyPressed do
            window.awaitEvent(maxWaitMillis) // skip other events

        println(s"KeyPressed: ${window.lastKey}")
        window.lastKey


object Mole:
    def dig(): Unit =
        var maxScreenWidth = BlockWindow.windowSize._1 / BlockWindow.blockSize
        var maxScreenHeight = BlockWindow.windowSize._2 / BlockWindow.blockSize
        var x = maxScreenWidth / 2
        var y = maxScreenHeight / 2
        var quit = false
        while !quit do
            BlockWindow.block(x, y)(Color.mole)
            val key = BlockWindow.waitForKey()
            if key == "w" && y > 0 then 
                BlockWindow.block(x, y)(Color.tunnel)
                y -= 1
            else if key == "a" && x > 0 then
                BlockWindow.block(x, y)(Color.tunnel)
                x -= 1
            else if key == "s" && y < maxScreenHeight - 1 then
                BlockWindow.block(x, y)(Color.tunnel)
                y += 1
            else if key == "d" && x < maxScreenWidth - 1 then
                BlockWindow.block(x, y)(Color.tunnel)
                x += 1
            else if key == "q" then quit = true
        BlockWindow.window.clear()
        sys.exit()

object Main:
    def drawWorld(): Unit =
        BlockWindow.rectangle(0, 0)(size = (30, 4))(Color.grass)
        BlockWindow.rectangle(0, 4)(size = (30, 46))(Color.soil)

@main def run(): Unit =
    Main.drawWorld()
    Mole.dig()
    
