import scala.io.StdIn.readLine
import scala.compiletime.ops.string

@main def irritext(): Unit = 
{
  println("Welcome to irritext!")
  println()

  // Ask for login
  // UserLogin()

  // Recipe game
  RecipeGame()
}

def UserLogin(): Unit =
{
  println("[LOGIN]")
  readLine("Enter your username: ")

  val correctPassword = "123"
  var hint = "[HINT: The password consists of three ascending numbers]"
  var guessAmount = 0;
  var askAgain = true
  while (askAgain)
  {
    val password = readLine("Enter your password: ")
    if (password == correctPassword) 
    {
      askAgain = false
    }
    else 
    {
      guessAmount += 1;
      if (guessAmount == 3) 
      {
        hint = "[HINT: The password is '321' backwards]"
      }
      println(s"Wrong password! Try again. $hint")
    }
  }

  println("Login successfull!")
}

def RecipeGame(): Unit =
{
  var chosenIngredients = Vector.empty[String]
  var availableIngredients = Vector("Chocolate", "Pasta", "Avocado", "Banana", "Tomato Sauce", "Meat", "Cheese", "Peanut Butter")

  var done = false
  while (!done)
  {
    println("Choose the four correct ingredients for a tasty spaghetti bolognese by typing the ingredient numbers one by one!")
    println()

    // Print chosen ingredients
    println("Currently chosen ingredients:")
    for (i <- 0 until chosenIngredients.size)  
    {
      println(chosenIngredients(i))
    }

    println()

    // Print available ingredients
    println("Available ingredients:")
    for (i <- 0 until availableIngredients.size)  
    {
      println((i+1) + ". " + availableIngredients(i))
    }

    readLine()
  }
}