//> using scala 3.5
import scala.io.StdIn.readLine

import scala.compiletime.ops.string

@main def irritext(): Unit = 
{
  println("Welcome to irritext!")
  println()

  // Ask for login
  UserLogin()

  println()

  // Recipe game
  RecipeGame()
}

def UserLogin(): Unit =
{
  println("[LOGIN]")
  readLine("Enter your username: ")

  val correctPassword = "123"
  var hint = "[HINT: The password consists of three ascending numbers]"
  var guessAmount = 0;
  var askAgain = true
  while (askAgain)
  {
    val password = readLine("Enter your password: ")
    if (password == correctPassword) 
    {
      askAgain = false
    }
    else 
    {
      guessAmount += 1;
      if (guessAmount == 3) 
      {
        hint = "[HINT: The password is '321' backwards]"
      }
      println(s"Wrong password! Try again. $hint")
    }
  }

  println("Login successfull!")
}

def RecipeGame(): Unit =
{
  var chosenIngredients = Vector.empty[String]
  var availableIngredients = Vector("Chocolate", "Pasta", "Avocado", "Banana", "Tomato Sauce", "Meat", "Cheese", "Peanut Butter")

  var done = false
  while (!done)
  {
    println("Choose the four correct ingredients for a tasty spaghetti bolognese by typing the ingredient numbers one by one!")
    println()

    // Print chosen ingredients
    println("Currently chosen ingredients:")
    PrintVectorContents(chosenIngredients, false)

    println()

    // Print available ingredients
    println("Available ingredients:")
    PrintVectorContents(availableIngredients, true)

    var validInput = false
    while (!validInput) 
    {
      var playerInput = readLine()
  
      if (playerInput.forall(c => c.isDigit) && !(playerInput.toInt < 1) && playerInput.toInt >= 1 && playerInput.toInt <= availableIngredients.size) 
      {
        chosenIngredients = chosenIngredients :+ availableIngredients(playerInput.toInt - 1)
        availableIngredients = availableIngredients.patch(playerInput.toInt - 1, Nil, 1)
        validInput = true
      }
      else
      {
        println("ERROR: Invalid input. Please try again.")
      }
    }

    if (chosenIngredients.size == 4) {
      if (chosenIngredients.contains("Pasta") && chosenIngredients.contains("Meat") && chosenIngredients.contains("Tomato Sauce") && chosenIngredients.contains("Cheese")) 
      {
        println("Yes! Thats correct. Congrats!")
        done = true
      } 
      else 
      {
        println("You chose the wrong ingredients. Try again.")
        chosenIngredients = Vector.empty[String]
        availableIngredients = Vector("Chocolate", "Pasta", "Avocado", "Banana", "Tomato Sauce", "Meat", "Cheese", "Peanut Butter")
        Thread.sleep(2000)
      }
    }
  }
}

def PrintVectorContents(vec : Vector[String], shouldNumerize : Boolean): Unit =
{
  if (vec.size == 0) 
    {
      println("Empty...")
    } else 
    {
      for (i <- 0 until vec.size)  
      {
        if (!shouldNumerize)
        {
          println(vec(i))
        }
        else 
        {
          println((i+1) + ". " + vec(i))
        }
      }
    }
}