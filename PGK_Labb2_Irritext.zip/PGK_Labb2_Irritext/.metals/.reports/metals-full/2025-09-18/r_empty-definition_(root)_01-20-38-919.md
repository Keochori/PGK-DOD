error id: file:///C:/Users/Mateusz/Desktop/LTH_PGK_DOD/PGK_Labb2_Irritext/irritext/src/main/scala/Main.scala:
file:///C:/Users/Mateusz/Desktop/LTH_PGK_DOD/PGK_Labb2_Irritext/irritext/src/main/scala/Main.scala
empty definition using pc, found symbol in pc: 
empty definition using semanticdb
empty definition using fallback
non-local guesses:
	 -askAgain.
	 -askAgain#
	 -askAgain().
	 -scala/Predef.askAgain.
	 -scala/Predef.askAgain#
	 -scala/Predef.askAgain().
offset: 311
uri: file:///C:/Users/Mateusz/Desktop/LTH_PGK_DOD/PGK_Labb2_Irritext/irritext/src/main/scala/Main.scala
text:
```scala
import scala.io.StdIn.readLine

@main def irritext(): Unit = 
{
    println("Welcome to irritext!")

    // Ask for login
    UserLogin()
}

def UserLogin(): Unit =
{
  val correctPassword = "123"

  println("[LOGIN]")
  readLine("Enter your username: ")

  var askAgain = true
  while (!askAg@@ain)
  {
    val password = readLine("Enter your password: ")
    if (password == correctPassword) {guessedCorrectly = true}
    else {println("Wrong password! Try again. [HINT: The password consists of three ascending numbers]")}
  }
}

```


#### Short summary: 

empty definition using pc, found symbol in pc: 